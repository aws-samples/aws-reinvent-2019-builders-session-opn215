#!/bin/bash
service aws-kinesis-agent start
service snortd start