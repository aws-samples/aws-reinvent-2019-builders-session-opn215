#!/bin/bash
service aws-kinesis-agent stop
service snortd stop