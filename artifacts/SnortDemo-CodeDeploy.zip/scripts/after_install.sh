#!/bin/bash
chmod +x /etc/rc.d/init.d/snortd
chmod +x /etc/init.d/snortd
chkconfig aws-kinesis-agent on
chkconfig snortd on