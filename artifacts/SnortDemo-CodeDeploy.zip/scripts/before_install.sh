#!/bin/bash
rm -f /etc/aws-kinesis/agent.json
rm -f /etc/rc.d/init.d/snortd
rm -f /etc/snort/snort.conf
rm -f /etc/snort/rules/local.rules
rm -f /etc/snort/rules/community.rules
rm -f /etc/snort/rules/black_list.rules
rm -f /etc/snort/rules/white_list.rules
rm -f /etc/sysconfig/snort